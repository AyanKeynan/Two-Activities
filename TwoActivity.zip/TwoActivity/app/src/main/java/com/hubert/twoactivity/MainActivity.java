package com.hubert.twoactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

     // Declare the EditText view
    private EditText messageEditText;
    // Declare and initialize  your key
    public static final String EXTRA_MESSAGE="Message yangu";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // initialize the Edit text

        messageEditText=findViewById(R.id.editText_Message);
    }

    public void launchSecondActivity(View view) {
       //create an intent
        Intent myIntent =new Intent(MainActivity.this, SecondActivity.class);
        //get the message typed by the user
        String message= messageEditText.getText().toString();
        //Put the message typed on the edit text inside the intent object you created using intent extra
        myIntent.putExtra(EXTRA_MESSAGE,message);
        //Start the second activity
        startActivity(myIntent);

    }
}