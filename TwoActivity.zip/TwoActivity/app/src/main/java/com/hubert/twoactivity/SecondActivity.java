package com.hubert.twoactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    // Declare the text view where you will display you message
    private TextView receivedMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        //initialize the textview
        receivedMessage=findViewById(R.id.textView_message);

        //creating an intent that gets the intent send
        Intent myIntent = getIntent();
        String myMessage = myIntent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        receivedMessage.setText(myMessage);

    }
}